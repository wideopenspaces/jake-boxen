# Atom Puppet Module for Boxen

## Usage

```puppet
include atom
```

## Required Puppet Modules

None.

## Developing

Write code.

Run `script/cibuild`.

