# Authy Puppet Module for Boxen
[![Build Status](https://travis-ci.org/pauloconnor/puppet-authy.png?branch=master)](https://travis-ci.org/pauloconnor/puppet-authy)

Installs [Authy Bluetooth Pairing](https://www.authy.com/thefuture) app

## Usage

```puppet
include authy
```

## Required Puppet Modules

* boxen
* stdlib
