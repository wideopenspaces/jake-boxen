# Htop Puppet Module for Boxen

## Usage

```puppet
include htop
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib
